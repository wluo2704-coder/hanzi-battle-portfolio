---
name: game-product-studio
description: Interview, structure, and govern a new or existing game project in Codex. Use when a user has a game idea, needs a game MVP workspace, wants to choose Unity/Unreal/Godot and a delivery mode, needs multi-agent game role contracts, or wants to add candidate/buildId, QA, Reflection, and recovery gates to an existing game project.
---

# Game Product Studio

Turn a game idea into a confirmed product brief and a governed, recoverable delivery workspace. Do not promise to make a commercial-quality game in one call.

## Operating boundaries

- Keep the user in control of core game direction, engine, presentation mode, budget, commercial model, and release authority.
- Do not initialize an engine project until the user confirms the brief and engine decision. Before that, use `ENGINE_DECISION: BLOCKED`.
- Do not create a long-lived Codex task, install this Skill globally, install dependencies, publish a Plugin/game, alter accounts/networking, or write outside the user-approved output root without explicit authorization.
- Give the game lead sole authority to write source, configuration, integration, Candidate, and formal delivery. Other roles supply bounded artifacts or read-only reviews.
- Treat `NOT TESTED` as unverified, never as PASS. A QA or Reflection PASS must name the same frozen buildId; any runtime-relevant change invalidates both.

## 1. Discover the product conversationally

Start with one question, or up to three tightly linked questions. Never begin with a long form. Read [discovery-interview.md](references/discovery-interview.md) before interviewing.

Capture, over several turns: player, desired feeling, core loop, references, session length, visual direction, devices, presentation/release mode, online needs, content scale, time/budget, and the user's capability and desired involvement. Explain unfamiliar terms in plain language. If the user is unsure, give the practical tradeoff and a recommendation, then ask them to decide.

Write `product_brief.md` and a proposed task card with every field labeled:

- `confirmed` — stated or approved by the user.
- `suggested` — a reversible Agent recommendation.
- `undecided` — needs a user choice; do not silently fill it.

Give the user a compact review and request confirmation. Do not bootstrap a project before confirmation.

## 2. Decide engine and presentation together

First distinguish browser-local runtime, cloud streaming, native desktop, mobile App, console, XR, and editor-only prototype. Then read [engine-selection.md](references/engine-selection.md) and compare Unity, Unreal, and Godot against the brief. Cite/recheck official engine documentation for version-dependent facts and record the check date.

Write `engine_decision.md` with the three-way comparison, recommendation, tradeoffs, unknowns, minimum spike, user choice, and confirmation. If there is no explicit choice, keep `ENGINE_DECISION: BLOCKED` and do not generate engine files.

## 3. Choose the smallest useful organization

Read [role-selection-rules.md](references/role-selection-rules.md) and select one mode:

- **Single-task MVP**: lead plus narrowly scoped, short-lived subagents.
- **Standard development**: independent design/content, art, QA, and Reflection responsibilities with lead integration.
- **Studio**: add technical, audio, release, or platform roles only when complexity justifies them.
- **Takeover**: audit an existing project before assigning ownership or accepting Candidate evidence.

Use [collaboration-and-gates.md](references/collaboration-and-gates.md) for role boundaries, lifecycle, evidence, and recovery. A long-lived role may be offered as a new task only if task creation is available **and** the user explicitly approves it. Otherwise generate startup packets.

## 4. Bootstrap only after confirmation

Use the bundled scripts with a user-approved output root. They create governance and starter artifacts, not an actual Unity/Unreal/Godot project.

```powershell
$python = 'PATH_TO_PYTHON'
& $python scripts/bootstrap_project.py --output-root 'D:\GameWork' --project-name 'Sky Hop' --mode greenfield --engine godot --engine-confirmed --brief 'D:\brief.json'
& $python scripts/generate_role_packets.py --project-root 'D:\GameWork\sky-hop' --scale standard --capability startup-packets
```

- `bootstrap_project.py` rejects an existing nonempty project and writes control files, task card, SOT, decision log, and engine-neutral project skeleton.
- `generate_role_packets.py` creates explicit role contracts and a manual fallback. It never creates tasks by itself.
- `generate_build_identity.py` creates a Candidate manifest from a frozen candidate directory and optional source snapshot.
- `validate_delivery_gates.py` verifies a manifest plus QA/Reflection gate records and exits nonzero on any missing, mismatched, or non-PASS gate.

Read [delivery-contracts.md](references/delivery-contracts.md) before changing the scripts' generated contracts. Use assets under `assets/project-templates/` when a user needs copyable Markdown instead of a generated project.

## 5. Run production in phases

1. Confirm Brief and engine.
2. Create the governed project workspace and role packets.
3. Let the lead integrate bounded contributions into a Candidate.
4. Freeze Candidate and generate a build identity.
5. QA verifies facts and runtime evidence; it does not change source.
6. Reflection audits goal/experience/claim fit; it does not change source.
7. Deliver only after both gates PASS on the same frozen buildId.

For interruption recovery, read the project task card, `progress_recap.md`, `execution_log.md`, then current Candidate and evidence. Do not require prior chat history.

## 6. Validate and report accurately

Run script help first, then success and failure paths. Check output roots, nonempty-target rejection, logs, exit codes, and a path containing spaces. For browser builds, validate real browser input and hosting behavior separately from engine/build success.

Before declaring completion, report the confirmed scope, project path, active buildId, QA/Reflection evidence, `NOT TESTED` items, authorizations not granted, and a safe next action. Do not claim global installation, task creation, Plugin publication, or game release unless it actually happened with user authorization.
