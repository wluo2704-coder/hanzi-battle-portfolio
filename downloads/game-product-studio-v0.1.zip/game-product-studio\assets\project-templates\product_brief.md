# Product Brief

| Field | Value | Status |
| --- | --- | --- |
| Players |  | confirmed / suggested / undecided |
| Core experience |  |  |
| Core loop |  |  |
| References |  |  |
| Session length |  |  |
| Visual direction |  |  |
| Target devices |  |  |
| Presentation |  |  |
| Release |  |  |
| Online |  |  |
| Content scope |  |  |
| Time / budget |  |  |
| User capability |  |  |
| User involvement |  |  |
| MVP hypothesis |  |  |
| Risks |  |  |
