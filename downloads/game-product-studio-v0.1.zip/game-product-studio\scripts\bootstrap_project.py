#!/usr/bin/env python3
"""Create an engine-neutral, governed game workspace after brief confirmation."""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(2)


def slug(value: str) -> str:
    result = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    if not result:
        fail("project name must contain at least one ASCII letter or digit")
    return result


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", required=True, help="User-approved parent directory")
    parser.add_argument("--project-name", required=True)
    parser.add_argument("--mode", choices=("greenfield", "takeover"), required=True)
    parser.add_argument("--engine", choices=("unconfirmed", "unity", "unreal", "godot"), required=True)
    parser.add_argument("--engine-confirmed", action="store_true", help="Use only after the user explicitly confirms engine and presentation")
    parser.add_argument("--brief", help="Optional UTF-8 JSON object of confirmed/suggested/undecided brief fields")
    args = parser.parse_args()

    root = Path(args.output_root).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        fail("--output-root must be an existing directory approved by the user")
    project = root / slug(args.project_name)
    if project.exists() and any(project.iterdir()):
        fail(f"refusing to overwrite nonempty project directory: {project}")
    brief: dict[str, object] = {}
    if args.brief:
        try:
            brief = json.loads(Path(args.brief).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            fail(f"cannot read --brief JSON: {exc}")
        if not isinstance(brief, dict):
            fail("--brief must contain a JSON object")

    if args.engine_confirmed and args.engine == "unconfirmed":
        fail("--engine-confirmed requires a concrete --engine")
    confirmed = args.engine != "unconfirmed" and args.engine_confirmed
    engine_state = "CONFIRMED" if confirmed else "BLOCKED"
    now = datetime.now(timezone.utc).isoformat()
    directories = (
        "00_admin", "01_product", "02_design", "03_art_content", "04_implementation",
        "05_validation/QA", "05_validation/Reflection", "06_candidates", "07_delivery",
        "role_startup_packets",
    )
    for relative in directories:
        (project / relative).mkdir(parents=True, exist_ok=True)

    brief_rows = "\n".join(
        f"| {key} | {value.get('value', '') if isinstance(value, dict) else value} | "
        f"{value.get('status', 'undecided') if isinstance(value, dict) else 'undecided'} |"
        for key, value in brief.items()
    ) or "| No interview data supplied |  | undecided |"
    write(project / "01_product/product_brief.md", f"# Product Brief｜{args.project_name}\n\n"
          "Generated from interview data. Do not treat `suggested` or `undecided` as confirmed.\n\n"
          "| Field | Value | Status |\n| --- | --- | --- |\n" + brief_rows + "\n")
    write(project / "01_product/engine_decision.md", f"# Engine & Presentation Decision\n\n"
          f"ENGINE_DECISION: {engine_state}\n\n"
          f"- Requested engine: `{args.engine}`\n- Project mode: `{args.mode}`\n"
          "- Presentation mode: undecided\n- Official documentation check date: pending\n"
          "- User confirmation: pending unless recorded below\n\n"
          "Do not create engine-specific files until the user explicitly confirms the selected engine and presentation mode.\n")
    write(project / "00_admin/task_card.md", f"# Task Card｜{args.project_name}\n\n"
          f"- Mode: `{args.mode}`\n- Engine decision: `{engine_state}`\n- Single source of truth: this card after user confirmation.\n"
          "- Scope: confirmed brief and approved MVP only.\n- Out of scope: unapproved platforms, monetization, services, release, and engine initialization.\n"
          "- Source authority: lead is sole writer for game source/config/integration/Candidate.\n")
    write(project / "00_admin/validation_protocol.md", "# Validation Protocol\n\n"
          "Verify structure, factual/runtime evidence, and user-goal fit. Bind QA and Reflection results to one frozen buildId.\n")
    write(project / "00_admin/execution_plan.md", "# Execution Plan\n\n"
          "Brief confirmation → engine decision → role packets → lead integration → frozen Candidate → QA → Reflection → delivery.\n")
    write(project / "00_admin/execution_log.md", f"# Execution Log\n\n- {now}: bootstrap completed; engine project not created.\n")
    write(project / "00_admin/progress_recap.md", "# Progress Recap\n\n"
          "## completed\n- Engine-neutral workspace created.\n\n## incomplete\n- Confirm brief, engine/presentation, roles, implementation, and gates.\n"
          "\n## last evidence\n- Bootstrap log.\n\n## next action\n- Review and confirm `01_product/product_brief.md` and `engine_decision.md`.\n")
    write(project / "00_admin/failure_memory.md", "# Failure Memory\n\n- Do not initialize an engine before explicit engine and presentation confirmation.\n"
          "- Any runtime-relevant change invalidates previous QA/Reflection evidence.\n")
    write(project / "00_admin/sot_and_decisions.md", "# SOT & Decisions\n\n"
          "1. User-confirmed task card\n2. Confirmed product brief and engine decision\n3. Frozen Candidate manifest and same-build evidence\n")
    log = {"event": "bootstrap", "created_at": now, "project": str(project), "mode": args.mode,
           "requested_engine": args.engine, "engine_decision": engine_state, "engine_project_created": False}
    write(project / "00_admin/bootstrap.log.json", json.dumps(log, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(log, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
