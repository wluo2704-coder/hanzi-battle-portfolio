#!/usr/bin/env python3
"""Generate bounded role contracts and manual startup packets; never create Codex tasks."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROLES = {
    "lead": ("Own source, configuration, integration, Candidate and formal delivery.", "04_implementation/ and 06_candidates/"),
    "design": ("Define approved game loop, content specifications and acceptance criteria.", "02_design/"),
    "art": ("Create a bounded asset package and integration notes.", "03_art_content/"),
    "technical": ("Advise on engine/platform risk; deliver technical plans, not integrated source.", "02_design/technical/"),
    "audio": ("Deliver a bounded audio package and implementation notes.", "03_art_content/audio/"),
    "qa": ("Verify facts and runtime evidence without changing Candidate or source.", "05_validation/QA/"),
    "reflection": ("Audit goal, experience and delivery claims without changing Candidate or source.", "05_validation/Reflection/"),
    "release": ("Prepare approved release checklist and rollback notes; do not publish without authorization.", "07_delivery/release_support/"),
}
SCALES = {
    "single": ("lead", "qa", "reflection"),
    "standard": ("lead", "design", "art", "qa", "reflection"),
    "studio": ("lead", "design", "art", "technical", "audio", "qa", "reflection", "release"),
    "takeover": ("lead", "qa", "reflection"),
}


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(2)


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--scale", choices=tuple(SCALES), required=True)
    parser.add_argument("--capability", choices=("startup-packets", "task-capable"), required=True)
    args = parser.parse_args()
    project = Path(args.project_root).expanduser().resolve()
    admin = project / "00_admin"
    if not admin.is_dir() or not (admin / "task_card.md").is_file():
        fail("--project-root must be a bootstrapped project with 00_admin/task_card.md")
    target = project / "role_startup_packets"
    target.mkdir(exist_ok=True)
    roles = SCALES[args.scale]
    for role in roles:
        goal, output = ROLES[role]
        forbidden = "All game source/configuration/integration/Candidate/formal delivery writes" if role != "lead" else "Unapproved external publication, task creation, or account/network changes"
        text = f"# Role Startup Packet｜{role.title()}\n\n## Goal\n\n{goal}\n\n## Source of truth\n\n"
        text += "`00_admin/task_card.md`, confirmed brief/engine decision, current progress recap and assigned inputs.\n"
        text += f"\n## Allowed output directory\n\n`{output}`\n\n## Forbidden writes\n\n{forbidden}.\n"
        text += "\n## Acceptance checks\n\nState evidence, unresolved assumptions, and `NOT TESTED` items.\n"
        text += "\n## Handoff\n\nSend the artifact path, decisions, evidence and recovery notes to the lead.\n"
        text += "\n## Escalate when\n\nScope, engine, user decision, external authorization, or write boundary must change.\n"
        text += "\n## Recovery order\n\nTask card → progress recap → execution log → current Candidate/evidence.\n"
        write(target / f"{role}_startup_packet.md", text)
    note = ("Task creation capability may exist, but this script did not create tasks. Obtain explicit user authorization before creating a long-lived task."
            if args.capability == "task-capable" else "Task creation is unavailable or unauthorized. Copy the packets manually in the listed order.")
    write(target / "START_HERE.md", "# Startup Order\n\n1. Lead\n2. Design/art or technical contributors\n3. Lead integration\n4. QA\n5. Reflection\n\n" + note + "\n")
    log = {"event": "generate_role_packets", "created_at": datetime.now(timezone.utc).isoformat(), "project": str(project),
           "scale": args.scale, "roles": roles, "capability": args.capability, "tasks_created": False}
    write(admin / "role_packets.log.json", json.dumps(log, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(log, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
