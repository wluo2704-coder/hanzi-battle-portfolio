# Role selection rules

## Complexity signals

Start with the lead only. Add a role when work is independently testable, requires a distinct craft, has a stable handoff, or creates unacceptable verification risk when left implicit.

| Signal | Add / change |
| --- | --- |
| One small loop, prototype deadline, low asset count | Lead + short-lived scoped subagents. |
| Multiple systems or sustained content/art work | Design/content and art roles with bounded output directories. |
| Candidate or release claim | QA and Reflection become mandatory independent roles. |
| Multi-platform, live/networked, accessibility, complex 3D | Add technical/platform/release specialists only for the affected scope. |
| Existing project without ownership/evidence | Takeover audit before new implementation. |

## Boundaries

- Lead: sole source/config/integration/Candidate/formal-delivery writer.
- Design/content and art: deliver specifications or asset packages to stated inbound directories; never modify the integrated game without lead approval.
- QA: read-only factual verification and `QA_GATE` report.
- Reflection: read-only goal/experience/evidence audit and `REFLECTION_GATE` report.

Independent tasks suit durable responsibilities. Subagents suit short, concrete, parallel work. If independent tasks cannot be created or are not authorized, emit a manual startup packet.
