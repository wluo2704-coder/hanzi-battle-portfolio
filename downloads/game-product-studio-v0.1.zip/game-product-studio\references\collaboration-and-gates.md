# Collaboration, Candidate, and gates

## Candidate contract

Create a frozen Candidate only after the lead finishes integration. Its manifest contains version, buildId, created time, candidate hash, optional source hash, schema/version, change summary, and paths to evidence. Any source, configuration, resource, scene, schema, build, or hosting change that can affect behavior invalidates prior gates.

## Gate contract

`QA_GATE: PASS` verifies factual/running evidence. `REFLECTION_GATE: PASS` verifies that the same candidate satisfies user goal, experience, and delivery claims. Both records must contain the manifest buildId. `FAIL`, `BLOCKED`, `NOT TESTED` for in-scope critical behavior, missing evidence, or a mismatched buildId blocks delivery.

## Decision tree

1. Is Brief confirmed? If no, interview.
2. Is engine/presentation confirmed? If no, compare and block initialization.
3. Are durable roles authorized and task creation available? If yes, offer task creation; otherwise generate packets.
4. Is Candidate frozen? If no, integrate and create manifest.
5. Do QA and Reflection PASS the same buildId? If no, repair or disclose/block; if yes, deliver exactly that candidate.

## Recovery

Store task card, validation protocol, execution plan/log, progress recap, failure memory, decision log, manifest, and evidence inside the project. Resume in that order; never depend on chat replay.
